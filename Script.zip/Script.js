
function otherfield(){
    var  x=document.getElementById("pop");
    if (x.style.display==="none") {
        x.style.display="block";
       
    } 
    else {
        x.style.display="none";
    }
}


/*  Refferences
For buttons : https://www.w3schools.com/tags/tag_button.asp
For 
*/